<script>
  import Todos from "./lib/Todos.svelte";
  
</script>

<main>

  <Todos />
</main>