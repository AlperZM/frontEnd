# Svelte + Vite

This template should help get you started developing with Svelte in Vite.

The entry point for the app can be found in /src/App.svelte.


See svelte.dev to get started with Svelte!


The autocompletion for JavaScript/TypeScript is disabled by default because it takes up too much memory with the Svelte autocompletion. If you have a Boosted Repl or Hacker Plan, try uncommenting the lines in `.replit` (a hidden file) to re-enable it!